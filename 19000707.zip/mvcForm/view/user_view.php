<?php
require '../model/use.php';
class UserView extends User{
    public function showStudent($firstname){
        $result = $this->searchStudent($firstname);
        echo "Full Name: ". $result[0]['fName']." ".$result[0]['lName'];
    }

    public function displayAll(){
        $all = $this->getAllStudents();
        echo " ";
    }
}
